import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

const getLogin = async () => {
  const login = await fetch(`http://localhost:3000/api/v1/auth/login`, {
    method: "GET",
    credentials: "include",
  });
  const data = await login.json();
  console.log("login", data.token);
};
await getLogin();

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
